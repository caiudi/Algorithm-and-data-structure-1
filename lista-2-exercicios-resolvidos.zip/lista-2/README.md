# Lista 2 — Comandos Condicionais em C

Resoluções dos **41 exercícios** da Lista C02 da FACOM/UFU, sobre `if`, `else` e `switch`.

Cada arquivo `exercicio-XX.c` contém o enunciado extraído do PDF original em comentário, a solução e observações quando necessário.

## Compilar e executar

```bash
gcc exercicio-01.c -o exercicio-01 -lm
./exercicio-01
```

No Windows (CMD), use `exercicio-01.exe` no lugar de `./exercicio-01`.

## Observações sobre ambiguidades da lista

- **Exercício 12:** O enunciado não especifica a base do logaritmo; foi adotado o logaritmo natural.
- **Exercício 13:** A aprovação é definida em 60 pontos, conforme o enunciado; as notas devem estar na mesma escala.
- **Exercício 26:** A tabela do PDF tem faixas sobrepostas (8 a 14 e maior que 12). Foi adotado: menor que 8, de 8 a 12, maior que 12.
- **Exercício 27:** A tabela indica Sênior para maiores de 18, deixando 18 sem categoria. Foi adotado 18 ou mais.
- **Exercício 28:** A expressão da média harmônica aparece diagramada como 1/(1/x + 1/y + 1/z); para a média harmônica usual de três números foi usado 3/(1/x + 1/y + 1/z).
- **Exercício 33:** Nas faixas do preço novo, foi adotado até 80, acima de 80 até 120, acima de 120 até 200, acima de 200.
- **Exercício 37:** Horários iguais foram interpretados como duração zero; o enunciado não diferencia zero de 24 horas.
- **Exercício 38:** O ano máximo foi mantido como 2008, conforme pedido explícito do PDF.
- **Exercício 41:** As faixas da tabela têm intervalos decimais; foram adotados limiares contínuos 18.5, 25, 30, 35 e 40.

Os exercícios foram compilados com GCC e verificados com testes de execução selecionados. As soluções são para estudo e devem ser revisadas conforme as orientações do professor.
